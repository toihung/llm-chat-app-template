﻿namespace ImageDownloader
{
    partial class MainForm
    {

    }
}

